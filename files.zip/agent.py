#!/usr/bin/env python3
"""
Agentic Game-Builder AI
Phases: Clarify → Plan → Execute
"""

import os
import json
import re
import sys
from anthropic import Anthropic

client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
MODEL = "claude-sonnet-4-20250514"

CLARIFIER_SYSTEM = """You are a game design consultant helping clarify requirements before building a game.

Your job:
1. Analyze the user's game idea
2. Identify ambiguities in: genre, mechanics, controls, win/loss conditions, visual style, complexity
3. Ask ONLY the most important clarifying questions (2-4 max per round)
4. When you have enough info, respond with exactly: CLARIFICATION_COMPLETE

Rules:
- Ask concise, specific questions
- Never ask about things already clearly stated
- Stop questioning once core mechanics, controls, win/loss, and style are clear
- Do NOT suggest or build anything yet"""

PLANNER_SYSTEM = """You are a senior game architect. Given a game concept and clarified requirements, produce a detailed technical plan.

Output a JSON object with this exact structure:
{
  "game_title": "string",
  "framework": "phaser" or "vanilla",
  "genre": "string",
  "description": "string",
  "mechanics": ["list of core mechanics"],
  "controls": {"key": "action"},
  "win_condition": "string",
  "lose_condition": "string",
  "visual_style": "string",
  "game_loop": "string description of the main loop",
  "systems": ["input", "rendering", "state", "collision", etc],
  "entities": [{"name": "string", "description": "string"}],
  "states": ["menu", "playing", "gameover", etc],
  "difficulty": "easy/medium/hard",
  "estimated_complexity": "simple/moderate/complex"
}

Output ONLY valid JSON, no markdown, no explanation."""

CODER_SYSTEM = """You are an expert game developer. Generate a complete, playable browser game.

Rules:
- Generate ALL THREE files: index.html, style.css, game.js
- The game must be fully playable in a browser with no server needed
- Use Phaser 3 (CDN) if framework is "phaser", otherwise pure vanilla JS
- The game must have: a start screen, gameplay, win/lose states
- Make it visually appealing with good UX
- All game logic in game.js, minimal style.css, clean index.html
- NO external assets (use Canvas drawing or CSS shapes only)
- Add comments to explain key sections

Output format - use these EXACT delimiters:
===FILE:index.html===
[html content]
===FILE:style.css===
[css content]
===FILE:game.js===
[js content]
===END==="""


def chat(system: str, messages: list, temperature: float = 0.7) -> str:
    response = client.messages.create(
        model=MODEL,
        max_tokens=8000,
        system=system,
        messages=messages,
        temperature=temperature,
    )
    return response.content[0].text


def phase_clarify(initial_idea: str) -> str:
    """Interactive clarification loop."""
    print("\n" + "="*60)
    print("PHASE 1: REQUIREMENTS CLARIFICATION")
    print("="*60)

    messages = [{"role": "user", "content": f"Game idea: {initial_idea}"}]
    conversation_history = [{"role": "user", "content": f"Game idea: {initial_idea}"}]

    round_num = 0
    max_rounds = 5

    while round_num < max_rounds:
        response = chat(CLARIFIER_SYSTEM, messages)
        messages.append({"role": "assistant", "content": response})
        conversation_history.append({"role": "assistant", "content": response})

        if "CLARIFICATION_COMPLETE" in response:
            print("\n✓ Requirements are clear. Moving to planning...\n")
            break

        print(f"\n[Agent - Round {round_num + 1}]:\n{response}\n")
        user_answer = input("Your answer: ").strip()

        if not user_answer:
            user_answer = "Use your best judgment."

        messages.append({"role": "user", "content": user_answer})
        conversation_history.append({"role": "user", "content": user_answer})
        round_num += 1

    # Build full requirements summary
    summary = f"Original idea: {initial_idea}\n\nConversation:\n"
    for msg in conversation_history[1:]:  # skip first (already in summary)
        role = "Agent" if msg["role"] == "assistant" else "User"
        summary += f"{role}: {msg['content']}\n\n"

    return summary


def phase_plan(requirements: str) -> dict:
    """Generate structured game plan."""
    print("="*60)
    print("PHASE 2: GAME PLANNING")
    print("="*60)

    messages = [{"role": "user", "content": f"Create a technical game plan for:\n\n{requirements}"}]
    response = chat(PLANNER_SYSTEM, messages, temperature=0.3)

    # Clean potential markdown
    clean = re.sub(r"```json\s*|\s*```", "", response).strip()

    try:
        plan = json.loads(clean)
        print(f"\n✓ Plan created: '{plan.get('game_title', 'Untitled')}'")
        print(f"  Framework: {plan.get('framework', 'vanilla').upper()}")
        print(f"  Genre: {plan.get('genre', 'unknown')}")
        print(f"  Mechanics: {', '.join(plan.get('mechanics', []))}")
        print(f"  Controls: {plan.get('controls', {})}")
        print()
        return plan
    except json.JSONDecodeError as e:
        print(f"Warning: Plan JSON parse error: {e}")
        print("Raw response:", response[:500])
        # Return a minimal plan
        return {
            "game_title": "My Game",
            "framework": "vanilla",
            "description": requirements,
            "mechanics": ["player movement", "collision"],
            "controls": {"Arrow Keys": "move"},
            "win_condition": "Reach the goal",
            "lose_condition": "Lose all lives",
            "game_loop": "Move, avoid obstacles, reach goal",
            "systems": ["input", "rendering", "state"],
            "states": ["menu", "playing", "gameover"],
        }


def phase_execute(requirements: str, plan: dict, output_dir: str) -> None:
    """Generate the actual game files."""
    print("="*60)
    print("PHASE 3: CODE GENERATION")
    print("="*60)
    print("Generating game files...\n")

    prompt = f"""Requirements summary:
{requirements}

Technical plan:
{json.dumps(plan, indent=2)}

Generate the complete game now."""

    messages = [{"role": "user", "content": prompt}]
    response = chat(CODER_SYSTEM, messages, temperature=0.4)

    # Parse the delimited files
    files = {}
    pattern = r"===FILE:(\S+)===\n(.*?)(?====FILE:|\===END===|$)"
    matches = re.findall(pattern, response, re.DOTALL)

    for filename, content in matches:
        files[filename.strip()] = content.strip()

    if not files:
        print("Warning: Could not parse file delimiters. Trying fallback...")
        # Fallback: look for common HTML/JS/CSS patterns
        html_match = re.search(r"(<!DOCTYPE html>.*?</html>)", response, re.DOTALL | re.IGNORECASE)
        if html_match:
            files["index.html"] = html_match.group(1)

    os.makedirs(output_dir, exist_ok=True)

    required = ["index.html", "style.css", "game.js"]
    for fname in required:
        if fname not in files:
            print(f"  Warning: {fname} not found in response")
            if fname == "style.css":
                files[fname] = "/* minimal styles */\nbody { margin: 0; background: #000; display: flex; justify-content: center; align-items: center; height: 100vh; }"
            elif fname == "game.js" and "index.html" in files:
                files[fname] = "// Game logic embedded in index.html"

    for fname, content in files.items():
        path = os.path.join(output_dir, fname)
        with open(path, "w") as f:
            f.write(content)
        size = len(content)
        print(f"  ✓ {fname} ({size:,} bytes)")

    # Save plan
    plan_path = os.path.join(output_dir, "game_plan.json")
    with open(plan_path, "w") as f:
        json.dump(plan, f, indent=2)
    print(f"  ✓ game_plan.json (metadata)")

    print(f"\n✓ Game '{plan.get('game_title', 'My Game')}' generated in: {output_dir}")
    print(f"  Open {os.path.join(output_dir, 'index.html')} in your browser to play!\n")


def run_agent():
    print("\n" + "="*60)
    print("  AGENTIC GAME-BUILDER AI")
    print("  Amgo Games Technical Assignment")
    print("="*60)

    # Get initial idea
    if len(sys.argv) > 1:
        idea = " ".join(sys.argv[1:])
        print(f"\nGame idea (from args): {idea}")
    else:
        print("\nDescribe your game idea (be as vague or specific as you like):")
        idea = input("> ").strip()

    if not idea:
        idea = "A fun browser game"

    output_dir = os.environ.get("OUTPUT_DIR", "./output")

    # Run the three phases
    requirements = phase_clarify(idea)
    plan = phase_plan(requirements)
    phase_execute(requirements, plan, output_dir)


if __name__ == "__main__":
    run_agent()
